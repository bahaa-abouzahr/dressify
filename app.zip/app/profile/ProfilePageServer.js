// import SelectCountry from "@/app/_components/SelectCountry";

// export default async function ProfilePageServer({ session }) {
//   const country = session.user.user_metadata?.nationality ?? "";

//   return (
//     <SelectCountry
//       name="nationality"
//       id="nationality"
//       className="profileFormInput shadow-sm"
//       defaultCountry={country}
//     />
//   );
// }