import CheckoutPageComponent from "../_components/CheckoutPageComponent"

export const metadata = {
  title: "Checkout",
}

function page() {
  return <CheckoutPageComponent />
}

export default page
