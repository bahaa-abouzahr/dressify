function SignOutMenuButton() {
  return (
    <button type="submit" className="category-link">
      Sign Out
    </button>
  )
}

export default SignOutMenuButton
